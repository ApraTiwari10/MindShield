/**
 * MindShield AI - Main Application Controller
 * Handles tab switching, state management, ML predictions, map, video call, and care features.
 */

const app = {
  activeTab: 'dashboard',
  currentPrediction: null,
  map: null,
  mapMarkers: [],
  breathingInterval: null,
  breathingState: 'stopped',
  selectedCounselor: null,
  isMicOn: true,
  isCamOn: true,

  // App Initialization
  init() {
    console.log("Initializing MindShield AI...");
    this.refreshLucideIcons();
    this.initDatasetTable();
    this.initTrendChart();
    
    // Initial prediction simulation for default values
    this.runDefaultPrediction();

    // Re-render icons on DOM content loaded
    document.addEventListener('DOMContentLoaded', () => {
      this.refreshLucideIcons();
    });
  },

  refreshLucideIcons() {
    if (window.lucide) {
      window.lucide.createIcons();
    }
  },

  // Tab Routing
  switchTab(tabId) {
    this.activeTab = tabId;

    // Update navigation button active state
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    const activeNavBtn = document.getElementById(`nav-${tabId}`);
    if (activeNavBtn) {
      activeNavBtn.classList.add('active');
    }

    // Hide all tabs & show active tab
    document.querySelectorAll('.tab-content').forEach(tab => {
      tab.classList.add('hidden');
    });
    const targetTab = document.getElementById(`tab-${tabId}`);
    if (targetTab) {
      targetTab.classList.remove('hidden');
    }

    // Tab-specific initializations
    if (tabId === 'gps') {
      setTimeout(() => this.initMap(), 100);
    } else if (tabId === 'recommendations') {
      this.renderRecommendations();
    } else if (tabId === 'counselors') {
      this.renderCounselors('all');
    } else if (tabId === 'mldashboard') {
      setTimeout(() => this.initFeatureChart(), 100);
    }

    // Close mobile menu if open
    document.getElementById('mobile-menu').classList.add('hidden');
    
    // Scroll smoothly to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.refreshLucideIcons();
  },

  toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    menu.classList.toggle('hidden');
  },

  // Form Sliders & Labels Synchronization
  updateSliderLabel(elementId, text) {
    const el = document.getElementById(elementId);
    if (el) el.innerText = text;
  },

  updateSelectLabel(elementId, text) {
    const el = document.getElementById(elementId);
    if (el) el.innerText = text;
  },

  // Default Prediction Simulation
  runDefaultPrediction() {
    const defaultInputs = {
      sleep: 7.5,
      stress: 4,
      mood: 75,
      social: 3,
      activity: 3,
      screen: 4
    };
    this.currentPrediction = MLEngine.predictRisk(defaultInputs);
    this.updateDashboardMetrics();
  },

  openAssessmentModal() {
    this.switchTab('assessment');
    document.getElementById('assessment-form').scrollIntoView({ behavior: 'smooth' });
  },

  // Handle ML Assessment Form Submit
  handleAssessmentSubmit(event) {
    event.preventDefault();
    
    const inputs = {
      sleep: document.getElementById('input-sleep').value,
      stress: document.getElementById('input-stress').value,
      mood: document.getElementById('input-mood').value,
      social: document.getElementById('input-social').value,
      activity: document.getElementById('input-activity').value,
      screen: document.getElementById('input-screen').value
    };

    // Run Machine Learning Classifier
    this.currentPrediction = MLEngine.predictRisk(inputs);

    // Render 3-Level Risk Result Card
    this.renderRiskResult(this.currentPrediction);
    this.updateDashboardMetrics();

    // Trigger celebration confetti if Low Risk
    if (this.currentPrediction.classification === 'Low Risk' && window.confetti) {
      window.confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    }
  },

  // Render 3-Level Risk Classification Card
  renderRiskResult(res) {
    const container = document.getElementById('risk-result-container');
    container.classList.remove('hidden');

    let badgeBg, borderBg, textTheme;
    if (res.classification === 'Low Risk') {
      badgeBg = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      borderBg = 'border-emerald-500/30';
      textTheme = 'text-emerald-400';
    } else if (res.classification === 'Moderate Risk') {
      badgeBg = 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      borderBg = 'border-amber-500/30';
      textTheme = 'text-amber-400';
    } else {
      badgeBg = 'bg-rose-500/20 text-rose-400 border-rose-500/40';
      borderBg = 'border-rose-500/30';
      textTheme = 'text-rose-400';
    }

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Classification Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div class="space-y-2">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">AI Machine Learning Result</span>
            <div class="flex items-center gap-3">
              <span class="text-3xl font-extrabold font-outfit ${textTheme}">${res.classification}</span>
              <span class="px-3.5 py-1 rounded-full text-xs font-bold border ${badgeBg} flex items-center gap-1.5">
                <i data-lucide="${res.riskIcon}" class="w-4 h-4"></i> ${res.compositeScore}% Risk Score
              </span>
            </div>
          </div>
          <div class="flex gap-2">
            <button onclick="app.switchTab('recommendations')" class="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-all flex items-center gap-1.5">
              <i data-lucide="sparkles" class="w-4 h-4"></i> View Personalized Care Plan
            </button>
            ${res.classification === 'High Risk' ? `
              <button onclick="app.switchTab('counselors')" class="bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-rose-600/40 transition-all flex items-center gap-1.5 animate-bounce">
                <i data-lucide="user-check" class="w-4 h-4"></i> Priority Counselor Booking
              </button>
            ` : ''}
          </div>
        </div>

        <!-- Risk Probabilities Distribution Bars -->
        <div class="space-y-3 bg-slate-900/60 p-5 rounded-2xl border border-slate-800">
          <h4 class="font-outfit font-bold text-sm text-white flex items-center gap-2">
            <i data-lucide="pie-chart" class="w-4 h-4 text-cyan-400"></i> ML Classification Probabilities
          </h4>
          <div class="grid grid-cols-3 gap-4 text-center">
            <div class="space-y-1">
              <div class="flex justify-between text-xs font-medium text-emerald-400">
                <span>Low Risk</span>
                <span>${res.probabilities.low}%</span>
              </div>
              <div class="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden">
                <div class="h-full bg-emerald-500 transition-all duration-700" style="width: ${res.probabilities.low}%"></div>
              </div>
            </div>
            <div class="space-y-1">
              <div class="flex justify-between text-xs font-medium text-amber-400">
                <span>Moderate</span>
                <span>${res.probabilities.moderate}%</span>
              </div>
              <div class="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden">
                <div class="h-full bg-amber-500 transition-all duration-700" style="width: ${res.probabilities.moderate}%"></div>
              </div>
            </div>
            <div class="space-y-1">
              <div class="flex justify-between text-xs font-medium text-rose-400">
                <span>High Risk</span>
                <span>${res.probabilities.high}%</span>
              </div>
              <div class="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden">
                <div class="h-full bg-rose-500 transition-all duration-700" style="width: ${res.probabilities.high}%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Top Identified Risk Factors -->
        <div class="space-y-3">
          <h4 class="font-outfit font-bold text-sm text-white">Top Identified Risk Triggers</h4>
          <div class="grid sm:grid-cols-3 gap-4">
            ${res.topTriggers.map(t => `
              <div class="bg-slate-900/70 p-4 rounded-xl border border-slate-800 space-y-1">
                <p class="text-xs text-slate-400 font-medium">${t.name}</p>
                <p class="text-sm font-bold text-slate-200 font-outfit">${t.val}</p>
                <span class="text-[10px] text-indigo-400">Factor Risk Level: ${Math.round(t.score * 100)}%</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    container.scrollIntoView({ behavior: 'smooth' });
    this.refreshLucideIcons();
  },

  // Update Overview Dashboard Badges
  updateDashboardMetrics() {
    if (!this.currentPrediction) return;
    const res = this.currentPrediction;

    const badge = document.getElementById('current-risk-badge');
    if (badge) {
      let colorClass = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      if (res.classification === 'Moderate Risk') colorClass = 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      if (res.classification === 'High Risk') colorClass = 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      
      badge.className = `px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${colorClass}`;
      badge.innerHTML = `<span class="w-2 h-2 rounded-full bg-current animate-pulse"></span> ${res.classification}`;
    }

    document.getElementById('last-eval-date').innerText = 'Just now';
  },

  // Support Feature 1: Render Personalized Care Plan
  renderRecommendations() {
    const container = document.getElementById('recommendations-container');
    if (!container) return;

    const res = this.currentPrediction || { classification: 'Low Risk' };
    const level = res.classification;

    let recs = [];
    if (level === 'Low Risk') {
      recs = [
        { title: 'Habit Consistency & Sleep Mastery', category: 'Sleep Hygiene', icon: 'moon', color: 'emerald', desc: 'Maintain regular 7-8 hour sleep schedules. Keep bedroom temperature at 65-68°F (18-20°C) for optimal REM cycle duration.' },
        { title: 'Pomodoro Productivity Intervals', category: 'Academic Focus', icon: 'clock', color: 'indigo', desc: 'Use 50-minute study blocks followed by 10-minute movement breaks to sustain cognitive focus without burnout.' },
        { title: 'Mindful Social Connections', category: 'Wellbeing', icon: 'heart', color: 'cyan', desc: 'Schedule 2 social activities per week (e.g. coffee with study group, outdoor walk) to maintain emotional resilience.' }
      ];
    } else if (level === 'Moderate Risk') {
      recs = [
        { title: 'Digital Sunset & Blue Light Cutoff', category: 'Sleep & Rest', icon: 'smartphone-off', color: 'amber', desc: 'Shut off non-study screens 60 minutes before sleep. Read or listen to calm ambient audio to lower night cortisol.' },
        { title: 'Stress Dumping & CBT Journaling', category: 'Stress Management', icon: 'book-open', color: 'purple', desc: 'Write down 3 main daily stress triggers and convert them into actionable 15-minute sub-tasks.' },
        { title: 'Guided 4-7-8 Vagus Nerve Breathing', category: 'Calm Routine', icon: 'wind', color: 'cyan', desc: 'Practice 3 cycles of 4-7-8 breathing twice daily to suppress sympathetic nervous system overdrive.' }
      ];
    } else {
      recs = [
        { title: 'Urgent Counselor Session Recommended', category: 'Priority Intervention', icon: 'alert-triangle', color: 'rose', desc: 'Schedule a 1-on-1 confidential session with a campus licensed psychologist within 24-48 hours.' },
        { title: 'Immediate Workload Relief & Academic Deferral', category: 'Academic Relief', icon: 'shield-alert', color: 'amber', desc: 'Contact student advisory to discuss assignment deadline extensions or temporary exam accommodations.' },
        { title: 'Daily Peer & Guardian Check-ins', category: 'Support Network', icon: 'users', color: 'indigo', desc: 'Connect with a trusted friend, family member, or counselor daily to prevent emotional isolation.' }
      ];
    }

    container.innerHTML = recs.map(r => `
      <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 hover:border-${r.color}-500/40 transition-all flex flex-col justify-between">
        <div class="space-y-3">
          <div class="flex justify-between items-center">
            <span class="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-${r.color}-500/10 text-${r.color}-400 border border-${r.color}-500/20">${r.category}</span>
            <div class="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-${r.color}-400 border border-slate-800">
              <i data-lucide="${r.icon}" class="w-4 h-4"></i>
            </div>
          </div>
          <h3 class="font-outfit font-bold text-base text-white">${r.title}</h3>
          <p class="text-slate-400 text-xs leading-relaxed">${r.desc}</p>
        </div>

        <div class="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
          <label class="flex items-center gap-2 cursor-pointer text-slate-300">
            <input type="checkbox" onchange="app.toggleActionItem(this)" class="rounded border-slate-700 text-indigo-600 focus:ring-indigo-500 bg-slate-950" />
            <span>Mark Complete</span>
          </label>
          <span class="text-slate-500 text-[11px]">Daily Goal</span>
        </div>
      </div>
    `).join('');

    this.refreshLucideIcons();
  },

  toggleActionItem(cb) {
    if (cb.checked && window.confetti) {
      window.confetti({ particleCount: 30, spread: 40, origin: { y: 0.8 } });
    }
  },

  // Support Feature 2: Counselor Assistance
  renderCounselors(specialtyFilter = 'all') {
    const container = document.getElementById('counselors-container');
    if (!container) return;

    let filtered = counselorsData;
    if (specialtyFilter !== 'all') {
      filtered = counselorsData.filter(c => c.specialty === specialtyFilter);
    }

    container.innerHTML = filtered.map(c => `
      <div class="glass-card p-6 rounded-3xl border border-slate-800 space-y-4 hover:border-slate-700 transition-all flex flex-col justify-between">
        <div class="space-y-4">
          <div class="flex gap-4 items-center">
            <img src="${c.avatar}" alt="${c.name}" class="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-500/30" />
            <div>
              <h3 class="font-outfit font-bold text-base text-white">${c.name}</h3>
              <p class="text-xs text-indigo-300 font-medium">${c.title}</p>
              <div class="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                <span class="text-amber-400 font-bold flex items-center gap-1"><i data-lucide="star" class="w-3 h-3 fill-amber-400"></i> ${c.rating}</span>
                <span>(${c.reviewsCount} reviews)</span>
                <span>• ${c.experience}</span>
              </div>
            </div>
          </div>

          <span class="inline-block px-3 py-1 rounded-full bg-slate-900 text-slate-300 text-[11px] border border-slate-800">${c.specialtyLabel}</span>
          <p class="text-slate-400 text-xs leading-relaxed line-clamp-2">${c.bio}</p>
        </div>

        <div class="space-y-3 pt-4 border-t border-slate-800">
          <p class="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
            <i data-lucide="calendar" class="w-3.5 h-3.5"></i> Next Slot: ${c.availableSlots[0]}
          </p>
          <button onclick="app.openBookingModal('${c.id}')" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-2.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2">
            <i data-lucide="calendar-check" class="w-4 h-4"></i> Book Consultation
          </button>
        </div>
      </div>
    `).join('');

    this.refreshLucideIcons();
  },

  filterCounselors(spec) {
    document.querySelectorAll('.counselor-filter-btn').forEach(btn => btn.classList.remove('active', 'bg-indigo-600/30', 'border-indigo-500/40', 'text-indigo-200'));
    this.renderCounselors(spec);
  },

  openBookingModal(counselorId) {
    const counselor = counselorsData.find(c => c.id === counselorId);
    if (!counselor) return;
    this.selectedCounselor = counselor;

    document.getElementById('modal-counselor-name').innerText = `Book Session with ${counselor.name}`;
    
    const slotsContainer = document.getElementById('modal-slots-container');
    slotsContainer.innerHTML = counselor.availableSlots.map((slot, idx) => `
      <label class="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 flex items-center gap-2 cursor-pointer hover:border-indigo-500">
        <input type="radio" name="modal-slot" value="${slot}" ${idx === 0 ? 'checked' : ''} class="text-indigo-600 accent-indigo-500" />
        <span>${slot}</span>
      </label>
    `).join('');

    document.getElementById('booking-modal').classList.remove('hidden');
  },

  closeBookingModal() {
    document.getElementById('booking-modal').classList.add('hidden');
  },

  confirmBooking() {
    this.closeBookingModal();
    alert(`Appointment Confirmed with ${this.selectedCounselor.name}!\nA calendar invite & session link has been dispatched.`);
    this.switchTab('videocall');
  },

  // Support Feature 3: GPS Map Locator (Leaflet.js)
  initMap() {
    if (this.map) {
      this.map.invalidateSize();
      return;
    }

    const defaultLat = 37.7749;
    const defaultLng = -122.4194;

    this.map = L.map('map').setView([defaultLat, defaultLng], 13);

    // Dark Map Tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap & CartoDB'
    }).addTo(this.map);

    // Render Markers & Nearby List
    this.renderMapMarkers();
    this.renderCentersList();
  },

  renderMapMarkers() {
    if (!this.map) return;

    centersData.forEach(center => {
      const marker = L.marker([center.lat, center.lng]).addTo(this.map);
      marker.bindPopup(`
        <div class="p-2 max-w-xs space-y-2">
          <h4 class="font-outfit font-bold text-sm text-white">${center.name}</h4>
          <p class="text-xs text-slate-400">${center.address}</p>
          <p class="text-xs text-indigo-400 font-semibold">${center.distance} • ${center.hours}</p>
          <a href="tel:${center.phone}" class="inline-block bg-indigo-600 text-white px-3 py-1 rounded text-[11px] font-bold mt-1">Call ${center.phone}</a>
        </div>
      `);
      this.mapMarkers.push(marker);
    });
  },

  renderCentersList() {
    const container = document.getElementById('centers-list');
    if (!container) return;

    container.innerHTML = centersData.map(c => `
      <div onclick="app.focusMapCenter(${c.lat}, ${c.lng})" class="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer space-y-2">
        <div class="flex justify-between items-start">
          <h4 class="font-outfit font-bold text-xs text-white">${c.name}</h4>
          <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-${c.typeColor}-500/20 text-${c.typeColor}-400 border border-${c.typeColor}-500/30">${c.type}</span>
        </div>
        <p class="text-[11px] text-slate-400">${c.address}</p>
        <div class="flex justify-between items-center text-[11px] pt-1">
          <span class="text-cyan-400 font-medium">${c.distance}</span>
          <a href="tel:${c.phone}" class="text-slate-300 hover:text-white font-semibold flex items-center gap-1">
            <i data-lucide="phone" class="w-3 h-3 text-emerald-400"></i> ${c.phone}
          </a>
        </div>
      </div>
    `).join('');

    this.refreshLucideIcons();
  },

  focusMapCenter(lat, lng) {
    if (this.map) {
      this.map.flyTo([lat, lng], 15);
    }
  },

  locateUserGPS() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(pos => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        if (this.map) {
          this.map.flyTo([lat, lng], 14);
          L.circleMarker([lat, lng], { color: '#06b6d4', radius: 8 }).addTo(this.map).bindPopup("You are here").openPopup();
        }
      }, () => {
        alert("GPS permissions denied or unavailable. Centering on campus default radius.");
      });
    }
  },

  // Support Feature 4: Tele-consultation Video Room
  toggleMic() {
    this.isMicOn = !this.isMicOn;
    const btn = document.getElementById('btn-mic');
    if (btn) {
      btn.className = `w-12 h-12 rounded-full ${this.isMicOn ? 'bg-slate-800 text-slate-200' : 'bg-rose-600 text-white'} flex items-center justify-center transition-all`;
    }
  },

  toggleCam() {
    this.isCamOn = !this.isCamOn;
    const btn = document.getElementById('btn-cam');
    if (btn) {
      btn.className = `w-12 h-12 rounded-full ${this.isCamOn ? 'bg-slate-800 text-slate-200' : 'bg-rose-600 text-white'} flex items-center justify-center transition-all`;
    }
  },

  toggleWhiteboard() {
    alert("Interactive Digital Whiteboard Opened for collaborative mood sketching!");
  },

  endVideoCall() {
    alert("Video Consultation Session Concluded. Session transcript notes saved to your profile.");
    this.switchTab('dashboard');
  },

  sendConsultationNote() {
    const input = document.getElementById('consultation-chat-input');
    if (input && input.value.trim()) {
      alert(`Note sent to Dr. Sarah Jenkins: "${input.value.trim()}"`);
      input.value = '';
    }
  },

  // ML Dashboard Charts
  initFeatureChart() {
    const ctx = document.getElementById('featureImportanceChart');
    if (!ctx) return;

    if (window.featureChartInstance) {
      window.featureChartInstance.destroy();
    }

    const labels = MLEngine.featureImportance.map(f => f.feature);
    const dataWeights = MLEngine.featureImportance.map(f => f.weight * 100);

    window.featureChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Feature Weight (%)',
          data: dataWeights,
          backgroundColor: [
            'rgba(99, 102, 241, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(6, 182, 212, 0.8)',
            'rgba(168, 85, 247, 0.8)',
            'rgba(16, 185, 129, 0.8)',
            'rgba(244, 63, 94, 0.8)'
          ],
          borderRadius: 8
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } },
          y: { grid: { display: false }, ticks: { color: '#f8fafc' } }
        }
      }
    });
  },

  initDatasetTable() {
    const tbody = document.getElementById('dataset-table-body');
    if (!tbody) return;

    tbody.innerHTML = studentDataset.map(row => `
      <tr class="hover:bg-slate-900/50 transition-colors">
        <td class="p-3 font-semibold text-white">${row.id}</td>
        <td class="p-3">${row.sleep} h</td>
        <td class="p-3">${row.stress}/10</td>
        <td class="p-3">${row.mood}</td>
        <td class="p-3">Level ${row.social}</td>
        <td class="p-3">${row.activity} d</td>
        <td class="p-3 font-bold text-slate-300">${row.target}</td>
        <td class="p-3 font-bold ${row.predicted === 'Low Risk' ? 'text-emerald-400' : row.predicted === 'Moderate Risk' ? 'text-amber-400' : 'text-rose-400'}">${row.predicted}</td>
      </tr>
    `).join('');
  },

  // Trend Analytics Chart
  initTrendChart() {
    const ctx = document.getElementById('trendChart');
    if (!ctx) return;

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [
          {
            label: 'Mood Index (0-100)',
            data: [70, 72, 68, 75, 80, 85, 82],
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6, 182, 212, 0.1)',
            tension: 0.4,
            fill: true
          },
          {
            label: 'Sleep Duration (hrs)',
            data: [6.5, 7.0, 6.0, 7.5, 8.0, 8.5, 7.5],
            borderColor: '#6366f1',
            tension: 0.4
          },
          {
            label: 'Stress Score (1-10 x10)',
            data: [60, 50, 65, 40, 30, 20, 30],
            borderColor: '#f59e0b',
            borderDash: [5, 5],
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#94a3b8', font: { family: 'Inter', size: 11 } } }
        },
        scales: {
          x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } },
          y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } }
        }
      }
    });
  },

  // Guided 4-7-8 Breathing Timer Loop
  toggleBreathingExercise() {
    const btn = document.getElementById('breathing-btn');
    const circle = document.getElementById('breathing-circle');
    const text = document.getElementById('breathing-text');
    const subtext = document.getElementById('breathing-subtext');

    if (this.breathingState === 'active') {
      clearInterval(this.breathingInterval);
      this.breathingState = 'stopped';
      btn.innerHTML = `<i data-lucide="play" class="w-4 h-4"></i> Start 60s Session`;
      circle.className = "w-28 h-28 rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-500 opacity-60 transition-all duration-1000 flex items-center justify-center shadow-2xl shadow-cyan-500/50";
      text.innerText = "Inhale";
      subtext.innerText = "Breathe in through nose (4s)";
      this.refreshLucideIcons();
      return;
    }

    this.breathingState = 'active';
    btn.innerHTML = `<i data-lucide="square" class="w-4 h-4"></i> Stop Session`;

    let step = 0; // 0: inhale (4s), 1: hold (7s), 2: exhale (8s)
    
    const runCycle = () => {
      if (step === 0) {
        circle.className = "w-28 h-28 rounded-full bg-cyan-500 opacity-100 scale-125 transition-all duration-1000 flex items-center justify-center shadow-2xl shadow-cyan-500/80";
        text.innerText = "Inhale";
        subtext.innerText = "Breathe in through nose (4s)";
        setTimeout(() => { if (this.breathingState === 'active') { step = 1; runCycle(); } }, 4000);
      } else if (step === 1) {
        circle.className = "w-28 h-28 rounded-full bg-purple-500 opacity-100 scale-125 transition-all duration-1000 flex items-center justify-center shadow-2xl shadow-purple-500/80";
        text.innerText = "Hold";
        subtext.innerText = "Hold your breath (7s)";
        setTimeout(() => { if (this.breathingState === 'active') { step = 2; runCycle(); } }, 7000);
      } else {
        circle.className = "w-28 h-28 rounded-full bg-indigo-600 opacity-50 scale-90 transition-all duration-1000 flex items-center justify-center shadow-2xl shadow-indigo-500/30";
        text.innerText = "Exhale";
        subtext.innerText = "Exhale fully through mouth (8s)";
        setTimeout(() => { if (this.breathingState === 'active') { step = 0; runCycle(); } }, 8000);
      }
    };

    runCycle();
    this.refreshLucideIcons();
  },

  // 24/7 AI Companion Chatbot
  toggleAIChat() {
    const drawer = document.getElementById('ai-chat-drawer');
    drawer.classList.toggle('hidden');
  },

  sendChatMessage() {
    const input = document.getElementById('chat-input');
    const container = document.getElementById('chat-messages');
    if (!input || !input.value.trim()) return;

    const userText = input.value.trim();
    input.value = '';

    // Append User Message
    container.innerHTML += `
      <div class="bg-indigo-600 text-white p-3 rounded-2xl rounded-tr-none max-w-[85%] ml-auto text-xs shadow-md">
        ${userText}
      </div>
    `;

    container.scrollTop = container.scrollHeight;

    // AI Response Logic
    setTimeout(() => {
      let aiReply = "I understand how you feel. Remember that taking small breaks and staying hydrated makes a huge difference. Would you like to try a 60-second breathing exercise?";
      
      const lower = userText.toLowerCase();
      if (lower.includes('sleep') || lower.includes('tired')) {
        aiReply = "Sleep deprivation can elevate stress hormones by up to 37%. Try setting a digital cutoff 1 hour before bed and listen to ambient rain sounds.";
      } else if (lower.includes('exam') || lower.includes('stress') || lower.includes('study')) {
        aiReply = "Exam stress is completely valid! Break your study material into 25-minute Pomodoro sessions. I can also help you book a quick chat with campus counselor Dr. Sarah Jenkins!";
      } else if (lower.includes('lonely') || lower.includes('sad')) {
        aiReply = "You are not alone. MindShield AI is here for you 24/7. Consider visiting the Student Wellness Center or connecting with peer support groups in the Care Plan tab!";
      }

      container.innerHTML += `
        <div class="bg-indigo-950/60 border border-indigo-800/40 text-slate-200 p-3 rounded-2xl rounded-tl-none max-w-[85%] text-xs shadow-md">
          ${aiReply}
        </div>
      `;
      container.scrollTop = container.scrollHeight;
    }, 600);
  },

  // Export PDF Report
  exportPDFReport() {
    alert("Generating confidential MindShield Mental Health PDF Summary Report for counselor review...");
    window.print();
  }
};

// Initialize App on window load
window.app = app;
window.onload = () => app.init();
