/**
 * Synthetic Student Mental Health Training Dataset Sample (N=1,200)
 * Used to demonstrate ML model validation, accuracy, and predictions.
 */

const studentDataset = [
  { id: 'STU-1082', sleep: 8.0, stress: 3, mood: 85, social: 4, activity: 5, target: 'Low Risk', predicted: 'Low Risk' },
  { id: 'STU-1083', sleep: 4.5, stress: 9, mood: 35, social: 1, activity: 0, target: 'High Risk', predicted: 'High Risk' },
  { id: 'STU-1084', sleep: 6.0, stress: 6, mood: 60, social: 2, activity: 2, target: 'Moderate Risk', predicted: 'Moderate Risk' },
  { id: 'STU-1085', sleep: 7.5, stress: 4, mood: 78, social: 3, activity: 4, target: 'Low Risk', predicted: 'Low Risk' },
  { id: 'STU-1086', sleep: 4.0, stress: 8, mood: 40, social: 2, activity: 1, target: 'High Risk', predicted: 'High Risk' },
  { id: 'STU-1087', sleep: 5.5, stress: 7, mood: 55, social: 3, activity: 2, target: 'Moderate Risk', predicted: 'Moderate Risk' },
  { id: 'STU-1088', sleep: 9.0, stress: 2, mood: 90, social: 4, activity: 6, target: 'Low Risk', predicted: 'Low Risk' },
  { id: 'STU-1089', sleep: 5.0, stress: 8, mood: 48, social: 1, activity: 1, target: 'High Risk', predicted: 'High Risk' },
  { id: 'STU-1090', sleep: 6.5, stress: 5, mood: 65, social: 3, activity: 3, target: 'Moderate Risk', predicted: 'Moderate Risk' },
  { id: 'STU-1091', sleep: 7.0, stress: 3, mood: 80, social: 4, activity: 4, target: 'Low Risk', predicted: 'Low Risk' }
];
