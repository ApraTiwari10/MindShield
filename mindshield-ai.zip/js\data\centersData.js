/**
 * GPS Support Centers & Nearby Mental Health Clinics Data
 */

const centersData = [
  {
    id: 'loc-1',
    name: 'University Student Health & Counseling Center',
    type: 'Campus Clinic',
    typeColor: 'indigo',
    distance: '0.4 km away',
    address: 'Building 4, Student Union Quad',
    phone: '(555) 019-2831',
    hours: '8:00 AM - 7:00 PM (Mon-Fri)',
    lat: 37.7749,
    lng: -122.4194,
    emergency: false,
    description: 'Free confidential drop-in counseling, group therapy rooms, and stress relaxation lounge.'
  },
  {
    id: 'loc-2',
    name: '24/7 University Medical Emergency Center',
    type: 'Emergency Facility',
    typeColor: 'rose',
    distance: '1.2 km away',
    address: '850 North University Drive',
    phone: '(555) 911-0022',
    hours: 'Open 24/7',
    lat: 37.7810,
    lng: -122.4120,
    emergency: true,
    description: 'Immediate psychiatric evaluation, crisis intervention, and urgent medical assistance.'
  },
  {
    id: 'loc-3',
    name: 'Hope Community Mental Health & Mind Hub',
    type: 'Community Clinic',
    typeColor: 'cyan',
    distance: '2.1 km away',
    address: '1420 Pine Street, Suite 300',
    phone: '(555) 438-9900',
    hours: '9:00 AM - 6:00 PM',
    lat: 37.7680,
    lng: -122.4280,
    emergency: false,
    description: 'Comprehensive outpatient mental health support, sliding scale therapy, and mindfulness workshops.'
  },
  {
    id: 'loc-4',
    name: 'Youth & Student Wellbeing Haven',
    type: 'Support Hub',
    typeColor: 'emerald',
    distance: '2.8 km away',
    address: '204 Berkeley Way',
    phone: '(555) 872-3311',
    hours: '10:00 AM - 8:00 PM',
    lat: 37.7850,
    lng: -122.4350,
    emergency: false,
    description: 'Peer support circles, sensory relaxation pods, and holistic wellness counseling.'
  }
];
