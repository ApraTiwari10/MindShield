/**
 * Licensed Student Mental Health Counselors Data
 */

const counselorsData = [
  {
    id: 'c1',
    name: 'Dr. Sarah Jenkins, Psy.D.',
    title: 'Lead Clinical Psychologist',
    specialty: 'anxiety',
    specialtyLabel: 'Anxiety & Exam Stress',
    rating: 4.9,
    reviewsCount: 124,
    experience: '12 yrs',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    bio: 'Specializing in cognitive behavioral therapy (CBT) for university academic pressure, test anxiety, and performance anxiety.',
    availableSlots: ['Today 3:00 PM', 'Tomorrow 10:30 AM', 'Thu 2:00 PM', 'Fri 11:00 AM']
  },
  {
    id: 'c2',
    name: 'Marcus Vance, LMFT',
    title: 'Behavioral Health Specialist',
    specialty: 'sleep',
    specialtyLabel: 'Sleep Hygiene & Burnout',
    rating: 4.8,
    reviewsCount: 98,
    experience: '8 yrs',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    bio: 'Focused on circadian rhythm optimization, digital fatigue, student burnout recovery, and stress management routines.',
    availableSlots: ['Today 4:30 PM', 'Wed 11:00 AM', 'Thu 4:00 PM', 'Fri 3:30 PM']
  },
  {
    id: 'c3',
    name: 'Dr. Elena Rostova, Ph.D.',
    title: 'Student Wellness Director',
    specialty: 'depression',
    specialtyLabel: 'Depression & Mood Regulation',
    rating: 5.0,
    reviewsCount: 156,
    experience: '15 yrs',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&auto=format&fit=crop&q=80',
    bio: 'Expert in mindfulness-based stress reduction (MBSR), emotion regulation, and helping students navigate major life transitions.',
    availableSlots: ['Tomorrow 9:00 AM', 'Thu 1:30 PM', 'Fri 10:00 AM']
  },
  {
    id: 'c4',
    name: 'David Chen, LCSW',
    title: 'Peer Relations & Counseling Specialist',
    specialty: 'anxiety',
    specialtyLabel: 'Social Anxiety & Adaptation',
    rating: 4.7,
    reviewsCount: 82,
    experience: '6 yrs',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    bio: 'Dedicated to helping international and first-year students combat isolation, build strong social networks, and thrive.',
    availableSlots: ['Today 5:00 PM', 'Wed 2:00 PM', 'Fri 4:00 PM']
  }
];
